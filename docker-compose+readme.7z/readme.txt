Add db-scripts and docker-compose.yml in the paren dir for the whole project:

>db-scripts
>e-commerce-backend
>e-commerce-frontend
-docker-compose.yml